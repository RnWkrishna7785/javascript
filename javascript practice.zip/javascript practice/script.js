// globe scope
// var_1 = 10
// var var_2 = "string"
// let var_3 = true
// const var_4 = 11.11


// block scope
// {

//     var_1 = 10
//     var var_2 = "string"

// under two not acces
//     let var_3 = true
//     const var_4 = 11.11
// }

// function scope

// (function () {
//     var_1 = 10
//     under three not acces
//     var var_2 = "string"
//     let var_3 = true
//     const var_4 = 11.11
// })();




// let a1 = "hello";
// let b2 = "dear";
// let c3 = `${a1} krishna ${b2}`;


// let val1 = 66;
// let val2 = 35;
// let val3 = val2++;
// val3 = val3--;
// let val4 = val1++;
// val2 = val2++;
// let val6 = ++val2;
// val1 = --val2;
// val2 = val3--;
// let val5 = val4++;
// console.log(val4)
// console.log(val1)
// console.log(val5)
// console.log(val3)
// console.log(val2)
// console.log(val6)

// let a = 22;
// let b = 21;
// let c = 10;
// if (a < b && a < c) {
//     document.write("a is greter than b and c")
// }
// else if(b < a && b < c){
//     document.write("b is greter than a and c")
// }
// else {
//     document.write("c is greter than a and b")
// }



// let val1 = 66;
// let val2 = 35;
// let val3 = val2++;
// val3 = val3--;
// let val4 = val1++;
// val2 = val2++;
// let val6 = ++val2;
// val1 = --val2;
// val2 = val3--;
// let val5 = val4++;
// document.write(val1);
// document.write(val2);
// document.write(val3);
// document.write(val4);
// document.write(val5);
// document.write(val6);

// let a = 0;
// let b = 1;
// if (++a && !++b) {
//     document.write("jsdkflak")
// }
// else {
//     document.write("ldfhsfjhs")
// }
// document.write("a :",a)
// document.write("b :",b)



// let a = 15;
// let b = 25;
// [b, a] = [a, b];   (second way of swap)
// let temp = a;      (first way of swap)
// a = b;
// b = temp;



// document.write("a="+ a);
// document.write("<br>")
// document.write("b="+b);




// Q1  this program find the value of minimum number using if else


// let a = 122;
// let c = 50;
// if (a  < c) {
//     document.write("minimum value is a:"+ a)
// }
// else {
//     document.write("minimum value is c:"+ c)
// }


// Q2 this program find the neutral number and negative or positive


// let x = Number(prompt("enter any number for x value:"))




// function checkNeutralNum(x) {
//     if (x > 0) {
//         document.write(x + " is a positive number.");
//     } else if (x < 0) {
//         document.write(x + " is a negative number.");
//     } else {
//         document.write(x + " is a neutral number.");
//     }
// }
// checkNeutralNum(x);


// Q3 swith case program
// pogram number-1

// const day = Number(prompt("enter the days number in 1 to 7"))

// switch (day) {
//     case 1:
//         document.write("monday");
//         break;
//     case 2:
//         document.write("monday");
//         break;
//     case 3:
//         document.write("monday");
//         break;
//     case 4:
//         document.write("monday");
//         break;
//     case 5:
//         document.write("monday");
//         break;
//     case 6:
//         document.write("monday");
//         break;
//     case 7:
//         document.write("monday");
//         break;
//     default:
//         document.write("this number not ragiter day")
// }

// pogram number-2

// const language = Number(prompt("enter the language in number 1-english 2-hindi 3-gujrati"))


// switch (language) {
//     case 1:
//         document.write("you choose english language")
//         document.write("<br>")


//         const recharge = Number(prompt("enter the recharge type in  number 1-internet 2-top-up 3-special"));

//         switch (recharge) {
//             case 1:
//                 document.write("You have successfully done a Internet Recharge");
//                 break;
//                 case 2:
//                     document.write("You have successfully done a Top-up Recharge");
//                     break;
//                     case 3:
//                         document.write("You have successfully done a special Recharge");
//                         break;
//             default:("invalied plese enter vaild number")
//                 break;
//          }
//         break;
//     case 2:
//         document.write("you choose hindi language")
//         document.write("<br>")


//         const recharge2 = Number(prompt("enter the recharge type in  number 1-internet 2-top-up 3-vishesh"));


//             switch (recharge2) {
//                 case 1:
//                     document.write("Aapne safaltapurvak Internet Recharge kar liya he");
//                     break;
//                     case 2:
//                         document.write("Aapne safaltapurvak Top-up Recharge kar liya he");
//                         break;
//                         case 3:
//                             document.write("Aapne safaltapurvak vishesh Recharge kar liya he");
//                             break;
//                 default:("invalied plese enter vaild number")
//                     break;
//              }
//         break;
//     case 3:
//         document.write("you choose gujrati language")
//         document.write("<br>")


//         const recharge3 = Number(prompt("enter the recharge type in  number 1-internet 2-top-up 3-vishesh"));


//             switch (recharge3) {
//                 case 1:
//                     document.write("tame safaltapurvak Internet recharge karyo che ");
//                     break;
//                     case 2:
//                         document.write("tame safaltapurvak Top-up recharge karyo che ");
//                         break;
//                         case 3:
//                             document.write("tame safaltapurvak vishesh recharge karyo che ");
//                             break;
//                 default:("invalied plese enter vaild number")
//                     break;
//              }
//         break;
//     default:
//         document.write("invalied plese enter vaild number")
//         break;
// }


// calculator

// let a = Number(prompt("enter the any digit "))
// let oprat = prompt("you oprate for your value in oprat + - * / % **")
// let b = Number(prompt("enter the any digit "))
// let output;
// switch (oprat) {
//     case "+":
//         output = a + b;

//         break;
//         case "-":
//             output = a - b;

//         break;
//         case "*":
//             output = a * b;

//         break;
//         case "/":
//             output = a / b;

//         break;
//         case "%":
//             output = a % b;

//         break;
//         case "**":
//             output = a ** b;

//             break;

//     default:
//         break;

// }
// document.write(output);



// let year = Number(prompt("enter the any year chek leap year ya not leap year"));

// if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
//   document.write(year + " is a leap year.");
// } else {
//   document.write(year + " is not a leap year.");
// }




// let varbal1=[47, 83, 98, 94, 52, 63];
// // document.writeln(varbal1[5]);
// // let varbal2 = [];
// // document.writeln(varbal2);

// varbal1[6] = 10;

// let sum = varbal1[0] + varbal1[1] + varbal1[2] + varbal1[3] + varbal1[4] + varbal1[5] + varbal1[6];

// document.writeln(varbal1);
// document.writeln(sum);





// ======== LOOPS ======
// // Q.1 Write a Program to print 1 to 10 using a for loop.
// for (let i = 1; i <= 10; i++) {
//     document.writeln(i);
// }
// // Q.2 Write a Program to print 10 to 1 using a for  loop.
// document.write("<br>")
// for (let j = 10; j >= 1; j--) {
//     document.writeln(j);
// }

// // Q.3 Write a Program to print 1 to N using a for loop.
// document.write("<br>")
// let n = Number(prompt("enter any number:"))

// for (let k= 1; k <= n; k++) {
//     document.writeln(k);
// }
// // Q.4 Write a Program to print odd numbers from N to 1 using a for loop.
// document.write("<br>")
// let m=Number(prompt("enter any number:"))

// for (let a=m; a>=1; a--) {
//     if (a%2!=0) {

//         document.writeln(a)
//     }
// }
// // Q.5 Write a Program to print even numbers from 1 to N using for loop.
// document.write("<br>")
// let p=Number(prompt("enter any number:"))

// for (let b=1; b<p; b++) {
//     if (b%2==0) {

//         document.writeln(b)
//     }
// }


// Q.6 Write a Program to print the Fibonacci series up to N numbers using a for loop.
// document.write("<br>")

// let c = Number(prompt("enter any number:"));
// let n1 = 0; n2 = 1;
// let swap;
// for (let d = 1; d <= c; d++){
//     document.writeln(n1);
//     swap = n1 + n2;
//     n1 = n2;
//     n2 = swap;
// }

// Q.6 Write a Program to print leap years between two given numbers using a for loop.
// document.write("<br>")

// let year1 = Number(prompt("enter the first year"));
// let year2 = Number(prompt("enter the second year"));

// for (let between = year1; between <= year2;between++ ) {
//     if ((between%4==0 && between%100!=0)|| between%400==0) {
//         document.writeln(between)
//     }

// }
// Q.7 Write a Program to print the multiplication table of the number N using for loop.
// document.write("<br>")

// let num = Number(prompt("enter you like any number"))
// let ans;
// for (let num1 = 1; num1 <= 10;num1++){
//     document.write("<br>")
//     ans = num * num1;
//     document.writeln(`${num}*${num1}=${ans}`);
// }



// Q.8 Print this using nested for loops
// let numstr = Number(prompt("enter any number"));
// for (let first = 1; first <= numstr; first++) {
//     document.write("<br>");
//     for (let secod = 1; secod <= first;secod++) {
//         document.writeln("*")

//     }
// }





// let arr = [11, 22, 33, 44, 55];

// let arr2D = [
//     ["krishna", "aayush", "poojan"],
//     ["mayur", "rutul", "sunil"],
//     ["sraddha", "vrushita", "priyanka"],
// ];
// const arr2d_0 = arr2D[0];
// console.log(arr2d_0);
// arr2d_0[2] = "chiku";
// console.log(arr2d_0[2]);

// console.log(arr2D[0][1]);
// console.log(arr2D[0]);

// console.log("========-");
// console.log(arr2D[1]);
// console.log(arr2D[1][2]);
// console.log("========-");
// console.log(arr2D[2]);
// console.log(arr2D[2][1]);
// console.log("========-");




// for (let i = 0; i < arr2D.length;i++){
//     console.log(arr2D[i]);
//     console.log(`=======array at : ${i}=====`);

//     for (let j = 0; j < arr2D[i].length;j++)
//         console.log(j,arr2D[i][j]);{

//     };

// }



// console.log("value log", "two");
// console.log(a);
// console.log(x);
// var a = 10;
// let x = 222;

// const f_name = function (x, xx) {
// let a = 20;
// console.log(a);
// console.log(x);
// console.log(xx);
// },
// f_name(x,xx);



// console.log("1prams", "2prams", "3prams");
// var a = 10;
// let x = 222;

// function f_name(val1,val2) {
//     let a = 100;
//     console.log(a);
//     console.log(val1);
//     val1 = "update";
//     console.log(val1);
//     console.log(val2);
// }
// f_name(a, x);




// let car = {
//     model: "ertiga",
//     engin: "900 cc",
//     type: ["petrol"],
//     num: 7890,
// };
// console.log({});
// console.log(Object());
// console.log(Object.keys(car));
// console.log(Object.values(car));
// console.log(Object.entries(car));




// function fname(a,x,name) {
//     console.log("basic function");
//     console.log("prams a:", a);
//     console.log("prams x as array:", x);
//     console.log(name);

//     a = 20;
//     x[0] = 20;
//     name["product"] = "mal2";

//     return [a, 10];
// }
// let parms1 = 10;
// const parms2 = [11, 22, 44, 32];
// const parms3 = {
//     item: "mmal",

// };
// let [data1, data2] = fname(parms1, parms2, parms3, "extra");
// console.log("prams1:", parms1);
// console.log("prams2:", parms2);
// console.log("prams3:", parms3);
// console.log("data1:", data1);
// console.log("data2:", data2);




// let val3;
// function sum(val1, val2) {
//  val3 = val1 + val2;
//     console.log(val3);
// }
// let item1 = 10;
// let item2 = 20;
// sum(item1, item2);
// let result = val3;
// console.log("result:", result);




// function sum(val1, val2) {
//     let val3 = val1 + val2;
//     return val3;
// }
// let item1 = 10;
// let item2 = 20;
// let result = sum(item1, item2);

// console.log("result:", result);



// // iife
// (function (value) {
//     console.log(value)
// })("jay shree ram")






// let num1 = 7979;
// let str = "this is my program";
// let obj = {
//     name: "krishna",
//     key:"0909",
// };

// let arrr = [11, 33, 35, 66, 66];

// console.log("before=============")
// console.log("num1:", num1);
// console.log("str:", str);
// console.log("obj:", obj);
// console.log("arrr:", arrr);
// console.log("before=============")

// function test1(num1) {
//     num1 = 100000;
//     return num1;
// }
// function test2(str) {
//     str = "this is my function program";
//     return str;
// }
// function test3(obj) {
//     obj["loction"] = "s.p.stidum";
//     obj["key"] = "k90k90";

// }
// function test4(arrr) {
//    arrr[3]=55 ;
//    arrr[5]=767 ;

// }
// num1 = test1(num1);
// str = test2(str);
//  test3(obj);
//  test4(arrr);
// console.log("after=============")
// console.log("num1:", num1);
// console.log("str:", str);
// console.log("obj:", obj);
// console.log("arrr:", arrr);
// console.log("after=============")







// create Object type
// 1-Object Literals
// const userprofile = {
//     firstname: "kajal",
//     lastname: "thakkar",
//     dob:"2000"
// };
// const userprofile = { firstname: "kajal", lastname: "thakkar", dob: "2000" };
// console.log( userprofile);



// get method using in object
// const userprofile = {
//         firstname: "kajal",
//         lastname: "thakkar",
//     dob: 2000,
//     getname: function () {
//         return "user's name:" + this.firstname + "" + this.lastname;
//     }
//     };

// console.log( userprofile);
// console.log( userprofile.getname());




// 2-Constructor Functions
// function user(firstname, lastname, dob) {
//     this.firstname = firstname;
//     this.lastname =lastname;
//     this.dob = dob;
// }
// const userprofile007 = new user("gagnbhai", "toba", 2025);
// console.log(userprofile007);
// const userprofile = { firstname: "kajal", lastname: "thakkar", dob: 2000 };
// console.log(userprofile);


// getmethod
// function user(firstname, lastname, dob) {
//     this.firstname = firstname;
//     this.lastname =lastname;
//     this.dob = dob;

//     this.getname = function () {
//         return "user's name:" + this.firstname + "" + this.lastname;
//     }
// }
// const userprofile007 = new user("gagnbhai", "toba", 2025);
// console.log(userprofile007);
// console.log(userprofile007.getname());


// 3-ecmascript6classes
// class user {
//     constructor(firstname, lastname, dob) {
//         this.firstname = firstname;
//         this.lastname = lastname;
//         this.dob = dob;

//         this.getname = function () {
//             return "user's name:" + this.firstname + "" + this.lastname;
//         }
//     }
// }
// const userprofile007 = new user("gagnbhai", "toba", 2025);
// console.log(userprofile007);
// console.log(userprofile007.getname());


// 4-Object.create method
// const userprofile0001 = {
//     firstname: "kajal",
//     lastname: "thakkar",
//     dob: 2000,
//     getname: function () {
//         return "user's name:" + this.firstname + "" + this.lastname;
//     }
// }
// const userprofile0002 = Object.create(userprofile0001);

// userprofile0002.firstname = "dinesh";
// userprofile0002.lastname = "goswami";
// userprofile0002.dob = 1970;


// console.log(userprofile0001);
// console.log(userprofile0001.dob);
// console.log(userprofile0001.getname());

// console.log(userprofile0002);
// console.log(userprofile0002.dob);
// console.log(userprofile0002.getname());










// let arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 55, 20];

// let i = 0;
// while (i < arr.length) {
//     if (arr[i] > 20) {
//         break;
//     }
//     if (arr[i]%2===1) {
//         i++;
//         continue;
//     }
//     console.log(arr[i]);
//     i++;
// }

// for (let i=0; i < arr.length; i++) {
//     if (arr[i] > 20){break;}
//     if (arr[i] % 2 === 1) {continue;}
//     console.log(arr[i]);
// };



// let i = 0;
// let n = 0;

// while (i < 5) {
//   i++;

//   if (i === 3) {
//     break;
//   }

//   n =n+ i;
// }
// console.log(n);
// for (let i = 0; i < 5; i++){
//     if (i === 3) {
//         break;
//     }
//     n = n + i;
// }
// console.log(n);





// let h1 = document.getElementById("h1");
// let h2 = document.getElementsByClassName("h2");
// let h3 = document.getElementsByName("h3");
// let h4 = document.getElementsByTagName("h4");
// let h5 = document.getElementById("h5");
// let h6 = document.getElementById("h6");



// let flag = true;
// function changename() {
    // const h1 = document.getElementsByClassName("name")[0];

    // h1.innerHTML = '<span class="up">nice singer darshn raval</span>';
    // h1.innerText = '<span class="up">nice singer darshn raval</span>';
    // h1.innerText = 'nice singer darshn raval';


    // if (flag) {
    // h1.innerHTML = '<span class="up">nice singer darshn raval</span>';
        
    // }
    // else {
    // h1.innerHTML = '<span class="up"> darshn raval</span>';
        
    // }
    // flag = !flag;
// }




// ========Q1========
// function _fname() {
//     for (let i = 1; i <= 10; i++) {
//         console.log(i);
//     }
// }

// _fname();
// ============Q2========
// function random() {
//     for (let i = 10; i >= 1; i--) {
//         console.log(i);
//     }
// }

// random();
// =========Q3==========
// let j = Number(prompt("enter any number"));
// function printNumbers(j) {
//     for (let i = 1; i <= j; i++) {
//         console.log(i);
//     }
// }

// printNumbers(j);
// =======Q4=======
// let j = Number(prompt("enter any number"));
// function odd(j) {
//     for (let i = j; i >= 1; i--) {
//         if (i % 2 !== 0) {
//             console.log(i);
//         }
//     }
// }

// odd(j);
// =========Q5========
// let j = Number(prompt("enter any number"));
// function Even(j) {
//     for (let i = 1; i <= j; i++) {
//         if (i % 2 === 0) {
//             console.log(i);
//         }
//     }
// }
// Even(j);
// =========Q6======
// let j = Number(prompt("enter any number"));
// function Fibonacci(j) {
//     let a = 0, b = 1;

//     for (let i = 1; i <= j; i++) {
//         console.log(a);
//         let swap = a + b;
//         a = b;
//         b = swap;
//     }
// }
// Fibonacci(j);
// ========Q7=======
// let sYear = Number(prompt("enter startyear"));
// let eYear = Number(prompt("enter enndyear"));

// function LeapYears(sYear, eYear) {
//     for (let year = sYear; year <= eYear; year++) {
//         if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
//             console.log(year);
//         }
//     }
// }

// LeapYears(sYear, eYear);
// =========Q8=======
// let num = Number(prompt("enter you like any number"))
// function multiplication(num) {
//     let ans;
    
//     for (let num1 = 1; num1 <= 10;num1++){
//         ans = num * num1;
//         console.log(`${num}*${num1}=${ans}`);
//     }
// }
// multiplication(num);
// ========Q9========

// let numstr = Number(prompt("enter any number"));
// function pettan(numstr) {
    
//     for (let first = 1; first <= numstr; first++) {
//         console.log("\n");
//         for (let secod = 1; secod <= first;secod++) {
//             console.log("*")
            
//         }
//     }
// }
// pettan(numstr);