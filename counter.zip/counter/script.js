const counter = document.querySelector(".counter-count h1");

function increment() {
    let count = Number(counter.innerHTML);
    counter.innerHTML = ++count;
}

function rest() {
    counter.innerHTML = "00";

}
function decrement() {
    let count = Number(counter.innerHTML);

    if (count !== 0) {
        counter.innerHTML = --count;
}
}